import ProvAxis from "./axis1.png";
import ProvIndosat from "./indosat1.png";
import ProvSmartfren from "./smartfren1.png";
import Provxl from "./xl1.png";
import ProvTelkomsel from "./telkomsel1.png";
import ProvPulsa from "./imageOperator1.png";
import ProvTopup from "./topup1.jpg";
import ProvUangDigital from "./UangElektronik1.png";

export {
  ProvAxis,
  ProvIndosat,
  ProvPulsa,
  ProvSmartfren,
  ProvTelkomsel,
  ProvTopup,
  ProvUangDigital,
  Provxl,
};
