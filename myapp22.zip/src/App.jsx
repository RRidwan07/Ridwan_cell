// import Home from "./Components/home";
import Home from "./Coba/components/Home";
// import Search from "./Utils/searchPulsa";
// import Card from "./Utils/card";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Eror from "./Coba/atoms/Eror";
import Cover from "./Coba/atoms/Cover/Cover";
import Dompet from "./Coba/components/Dompet";
import CoverDompet from "./Coba/atoms/Cover/CoverDompet";

const App = () => {
  return (
    <div
      data-theme="garden"
      className="h-screen absolute w-screen overflow-scroll overflow-x-hidden "
    >
      {/* <Search />
      <Home /> */}
      <BrowserRouter>
        <Routes>
          <Route path="*" element={<Eror />} />
          <Route path="/" element={<Home />} />
          <Route path="/cover/:providerName" element={<Cover />} />
          <Route path="/coverDompet/:providerName" element={<CoverDompet />} />
          <Route path="/dompet" element={<Dompet />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default App;
