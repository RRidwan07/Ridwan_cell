import { useNavigate } from "react-router-dom";
import HomeCover from "../atoms/HomeCover";

const Home = () => {
  const navigate = useNavigate();
  const Datas = [
    {
      name: "Indosat",
    },
    {
      name: "Axis",
    },
    {
      name: "Xl",
    },
    {
      name: "Smartfren",
    },
    {
      name: "Telkomsel",
    },
  ];

  return (
    <div>
      <h1>Hello word</h1>
      {Datas.map((data, i) => (
        <HomeCover key={i} product={data.name} link="cover" />
      ))}
      <div onClick={() => navigate("/dompet")}>Dompet Digital</div>
    </div>
  );
};

export default Home;
