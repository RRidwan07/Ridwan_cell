import PropTypes from "prop-types";
import { useNavigate } from "react-router-dom";
import { GrHomeRounded } from "react-icons/gr";

const Navbar = ({ providerName }) => {
  const navigate = useNavigate();

  const goBack = () => {
    navigate("/"); // Ini akan membawa pengguna kembali ke halaman sebelumnya
  };

  return (
    <div className="navbar flex justify-center  bg-cyan-300">
      <div className="flex justify-start">
        <GrHomeRounded onClick={goBack} size={25} />
      </div>
      <div className="">
        <a className="text-xl font-bold ">{providerName}</a>
      </div>
    </div>
  );
};

Navbar.propTypes = {
  providerName: PropTypes.string.isRequired,
};

export default Navbar;
