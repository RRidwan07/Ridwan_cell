import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";

const HomeCover = ({ product, link }) => {
  const navigate = useNavigate();
  const handlePress = () => {
    navigate(`/${link}/${product}`);
  };
  return (
    <div onClick={handlePress}>
      <h1>{product}</h1>
    </div>
  );
};

HomeCover.propTypes = {
  product: PropTypes.string.isRequired,
  link: PropTypes.string.isRequired,
};

export default HomeCover;
