const Eror = () => {
  return <div>Eror No path</div>;
};

export default Eror;
