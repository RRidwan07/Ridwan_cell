import IndosatP from "./Indosat";
import AxisP from "./Axis";
import SmartfrenP from "./Smartfren";
import TelkomselP from "./Telkomsel";
import XlP from "./Xl";

export { IndosatP, AxisP, SmartfrenP, TelkomselP, XlP };
