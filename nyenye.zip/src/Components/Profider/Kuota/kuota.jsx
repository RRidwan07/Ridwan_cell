import IndosatK from "./Indosat";
import AxisK from "./Axis";
import SmartfrenK from "./Smartfren";
import XlK from "./Xl";
import TelkomselK from "./Telkomsel";

export { IndosatK, AxisK, XlK, SmartfrenK, TelkomselK };
