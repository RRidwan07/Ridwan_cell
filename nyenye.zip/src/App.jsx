import Home from "./Components/home";

const App = () => {
  return (
    <div
      data-theme="garden"
      className="h-screen absolute w-screen overflow-scroll overflow-x-hidden "
    >
      <Home />
    </div>
  );
};

export default App;
